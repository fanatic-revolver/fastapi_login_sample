import pymysql
from fastapi import FastAPI
from peewee import *
from playhouse.db_url import connect
from pydantic import BaseModel

pymysql.install_as_MySQLdb()

db = connect('mysql://root:root@localhost:3306/test')
app = FastAPI()


class GoodsModel(Model):
    name = CharField()
    price = FloatField()

    class Meta:
        database = db
        db_table = "goods"


class GoodsSchema(BaseModel):
    name: str  # 商品名称
    price: float  # 商品价格


def get_response(data=None):
    response = {"code": 10000, "msg": "success", "status": True}
    if data is not None:
        response["data"] = data
    return response


def get_response_error(code, msg):
    return {"code": code, "msg": msg, "status": False}


# http://localhost:8000/docs
# http://localhost:8000/goods
@app.post("/goods")
async def post_goods(goods: GoodsSchema):
    try:
        goods_model = GoodsModel(**goods.dict())
        goods_model.save()
        return get_response()
    except Exception as e:
        print(e)
        return get_response_error(10003, "保存商品数据失败")


@app.get("/goods/{gid}")
async def get_goods_by_id(gid: int):
    try:
        goods = GoodsModel.get(gid)
        return get_response(goods.__data__)
    except Exception as e:
        print(e)
        return get_response_error(10004, "商品不存在")


# http://localhost:8000/goods
@app.get("/goods")
async def get_goods(page: int = 1, size: int = 20):
    query = GoodsModel.select()
    count = query.count()
    result = query.paginate(page, size).dicts()
    data = {
        "total": count,
        "data": list(result)
    }
    return get_response(data)


@app.put("/goods/{gid}")
async def put_goods(gid: int, goods: GoodsSchema):
    try:
        goods_model = GoodsModel.get(gid)
        goods_model.name = goods.name
        goods_model.price = goods.price
        goods_model.save()
        return get_response()
    except Exception as e:
        return get_response_error(10004, "商品不存在")


@app.delete("/goods/{gid}")
async def delete_goods(gid: int):
    try:
        GoodsModel.get(gid).delete_instance()
    except Exception as e:
        pass
    return get_response()


if __name__ == '__main__':
    import uvicorn

    uvicorn.run("main:app")
