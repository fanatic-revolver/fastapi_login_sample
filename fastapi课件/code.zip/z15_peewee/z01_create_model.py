import pymysql
from peewee import *
from playhouse.db_url import connect

pymysql.install_as_MySQLdb()

db = connect('mysql://root:root@localhost:3306/test')


class Goods(Model):
    name = CharField()
    price = FloatField()

    class Meta:
        database = db


db.connect()
