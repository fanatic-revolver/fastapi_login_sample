from fastapi import FastAPI

app = FastAPI()

@app.get("/")
async def index():
    return "ok"

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app")