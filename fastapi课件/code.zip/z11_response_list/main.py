from fastapi import FastAPI

app = FastAPI()

@app.get("/")
async def index():
    return [{"name":"zs"},{"name":"ls"}]

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app")