from fastapi import FastAPI


app = FastAPI()


@app.get("/")
async def index(name: str, age: int):
    return {"name": name, "age": age}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app")