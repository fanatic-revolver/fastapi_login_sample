import random
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

# 模拟数据库
db = {
    i: {"name": f"《React学习手册{i}》", "price": random.randint(30, 200)}
    for i in range(1, 100)
}
db_id = 1  # 模拟ID


def get_response(data=None):
    response = {"code": 10000, "msg": "success", "status": True}
    if data is not None:
        response["data"] = data
    return response


class Goods(BaseModel):
    name: str  # 商品名称
    price: float  # 商品价格


@app.post("/goods")
async def post_goods(goods: Goods):
    global db_id
    db[db_id] = goods.dict()
    db_id += 1
    return get_response()


@app.get("/goods/{gid}")
async def get_goods_by_id(gid: int):
    goods = db.get(gid)
    return get_response(data=goods)


@app.get("/goods")
async def get_goods(page: int = 1, size: int = 20):
    start_index = (page - 1) * size
    end_index = start_index + size
    page_data = [
        db.get(i)
        for i in range(start_index, end_index+1)
    ]
    data = {
        "total": len(db),
        "page": page,
        "size": size,
        "data": page_data
    }
    return get_response(data)


@app.put("/goods/{gid}")
async def put_goods(gid: int, goods: Goods):
    target = db.get(gid)
    if target is None:
        del db[gid]
    db[gid] = goods.dict()
    return get_response()


@app.delete("/goods/{gid}")
async def delete_goods(gid: int):
    target = db.get(gid)
    if target is not None:
        del db[gid]
    return get_response()


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app")
