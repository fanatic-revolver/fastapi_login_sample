import random

db = [
    {"id": i, "name": f"《React学习手册{i}》", "price": random.randint(20, 200)}
    for i in range(1, 101)
]

print(type(db))
print(db)