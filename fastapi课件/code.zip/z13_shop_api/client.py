import requests

# 新增商品
target_url = "http://localhost:8000/goods"
data = {"name": "测试", "price": 33.33}
response = requests.post(target_url, json=data)
print("测试新增商品：", response.text)

# 根据id获取商品
target_url = "http://localhost:8000/goods/33"
response = requests.get(target_url)
print("测试根据id获取商品：", response.text)

# 根据id删除商品
target_url = "http://localhost:8000/goods/34"
response = requests.delete(target_url)
print("测试根据id删除商品：", response.text)

# 根据id修改商品
target_url = "http://localhost:8000/goods/33"
data = {"name": "测试333", "price": 33.33}
response = requests.put(target_url, json=data)
print("测试根据id修改商品：", response.text)

# 分页获取商品
target_url = "http://localhost:8000/goods?page=1&size=20"
response = requests.get(target_url)
print("测试分页获取商品：", response.text)
