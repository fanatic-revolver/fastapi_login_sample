import requests


target_url="http://localhost:8000/zhangdapeng/33"
response=requests.get(target_url)
print(response.text)