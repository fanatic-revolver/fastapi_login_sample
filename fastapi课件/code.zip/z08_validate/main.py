from fastapi import FastAPI, Path, Query

app = FastAPI()

@app.get("/{name}")
async def index(
    name:str=Path(min_length=3,max_length=32),
    age:int=Query(0,gt=0,lte=200),
):
    return {"name":name, "age":age}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app")