import requests

# 登录获取token
target_url = "http://localhost:8000/token"
data = {"username": "zhangdapeng", "password": "zhangdapeng520"}
response = requests.post(target_url, data=data)
print("测试登录获取token：", response.text)

# 获取当前用户
token = response.json()["access_token"]
headers = {"Authorization": "Bearer " + token}
target_url = "http://localhost:8000/users/me/"
response = requests.get(target_url, headers=headers)
print("测试获取当前用户：", response.text)

# 获取当前数据
headers = {"Authorization": "Bearer " + token}
target_url = "http://localhost:8000/users/me/items/"
response = requests.get(target_url, headers=headers)
print("测试获取当前用户数据：", response.text)
