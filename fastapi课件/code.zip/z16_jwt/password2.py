from passlib.context import CryptContext

# 密码加密对象
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# 原始密码
password_str = "zhangdapeng"

# 密码加密
secret = pwd_context.hash(password_str)
print("加密后的密码：", secret)

# 校验密码是否正确
is_ok = pwd_context.verify(password_str, secret)
print("密码是否正确：", is_ok)
