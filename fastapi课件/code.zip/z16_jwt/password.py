from passlib.context import CryptContext

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

if __name__ == '__main__':
    # 生成密码
    password_str = "zhangdapeng520"
    password = pwd_context.encrypt(password_str)
    print(password)

    # 校验密码
    print(pwd_context.verify(password_str, password))
