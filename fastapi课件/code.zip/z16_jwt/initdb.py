import pymysql
from peewee import *
from playhouse.db_url import connect

pymysql.install_as_MySQLdb()

# 连接指定数据库
db = connect("mysql://root:root@localhost:3306/test")


# 创建用户表
class User(Model):
    username = CharField()
    password = CharField()
    role_id = IntegerField()

    class Meta:
        database = db


db.connect()


def init_db():
    tables = [User]
    db.create_tables(tables)


if __name__ == '__main__':
    init_db()

    user = User.get(username="zhangdapeng")
    print(user.id)
    print(user.username)
    print(user.password)


