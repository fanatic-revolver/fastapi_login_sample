from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

class Student(BaseModel):
    name:str
    age:int

@app.get("/")
async def index():
    return Student(name="zs",age=33)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app")