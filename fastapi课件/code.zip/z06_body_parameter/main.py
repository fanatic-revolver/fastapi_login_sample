from fastapi import FastAPI, Body


app = FastAPI()


@app.get("/")
async def index(name: str=Body(), age: int=Body(33)):
    return {"name": name, "age": age}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app")