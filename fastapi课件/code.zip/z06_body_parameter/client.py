import requests


target_url="http://localhost:8000"
data={"name":"zhangdapeng"}
response=requests.get(target_url,json=data)
print(response.text)