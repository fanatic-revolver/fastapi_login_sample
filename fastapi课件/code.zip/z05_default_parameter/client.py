import requests


target_url="http://localhost:8000?name=zhangdapeng"
response=requests.get(target_url)
print(response.text)