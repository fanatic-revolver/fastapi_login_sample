from schema import UserInDB
from utils import verify_password

# 模拟用户数据
fake_users_db = {
    "zhangdapeng": {
        "username": "zhangdapeng",
        "full_name": "张大鹏",
        "email": "zhangdapeng@zhangdapeng.com",
        "hashed_password": "$2b$12$4Te1//FDmF0YPYuskhsWdeT9vwgZB3v7O.OL3X64guEyaGL8/8sFK",
        "disabled": False,
    }
}


def get_user(db, username: str):
    """模拟从数据库获取用户信息"""
    if username in db:
        user_dict = db[username]
        return UserInDB(**user_dict)


def authenticate_user(fake_db, username: str, password: str):
    """校验用户"""
    # 从数据库获取用户
    user = get_user(fake_db, username)
    # 校验用户是否存在
    if not user:
        return False
    # 校验用户密码是否正确
    if not verify_password(password, user.hashed_password):
        return False
    # 校验通过，返回数据库查到的用户信息
    return user
