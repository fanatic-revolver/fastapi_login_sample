from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt

from db import fake_users_db, get_user
from schema import TokenData, User
from utils.jwt import SECRET_KEY, ALGORITHM

# 文档OAuth2登录
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")


async def get_current_user(token: str = Depends(oauth2_scheme)):
    """获取当前登录用户"""
    # 异常对象
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )

    try:
        # 解析客户端传过来的JWT Token
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        # 获取用户名
        username: str = payload.get("sub")
        # 校验用户名是否存在
        if username is None:
            raise credentials_exception
        # 封装token数据
        token_data = TokenData(username=username)
    except JWTError:
        raise credentials_exception
    # 从数据库获取用户
    user = get_user(fake_users_db, username=token_data.username)
    # 校验用户是否存在
    if user is None:
        raise credentials_exception
    # 返回获取到的用户
    return user


async def get_current_active_user(current_user: User = Depends(get_current_user)):
    """获取激活的用户"""
    # 校验用户是否被禁用
    if current_user.disabled:
        raise HTTPException(status_code=400, detail="Inactive user")
    # 返回用户信息
    return current_user
