from typing import Union

from pydantic import BaseModel


class Token(BaseModel):
    """token模型"""
    access_token: str  # jwt token
    token_type: str  # token 类型


class TokenData(BaseModel):
    """token内部数据"""
    username: Union[str, None] = None  # 用户名


class User(BaseModel):
    """用户模型"""
    username: str  # 用户名
    email: Union[str, None] = None  # 邮箱
    full_name: Union[str, None] = None  # 全名
    disabled: Union[bool, None] = None  # 是否禁用


class UserInDB(User):
    """入库的用户模型"""
    hashed_password: str  # 加密密码
