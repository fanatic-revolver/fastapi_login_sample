from passlib.context import CryptContext

# 密码加密对象
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def verify_password(plain_password, hashed_password):
    """校验密码是否正确"""
    return pwd_context.verify(plain_password, hashed_password)


def get_password_hash(password):
    """密码加密"""
    return pwd_context.hash(password)
