from datetime import timedelta, datetime
from typing import Union

from jose import jwt

# 生成私钥的命令：openssl rand -hex 32
SECRET_KEY = "09d25e094faa6ca2556c818166b7a9563b93f7099f6f0f4caa6cf63b88e8d3e7"
ALGORITHM = "HS256"  # 加密算法
ACCESS_TOKEN_EXPIRE_MINUTES = 30  # token过期时间（分钟）


def create_access_token(data: dict, expires_delta: Union[timedelta, None] = None):
    """创建JWT Token"""
    # 提交要打包的token内部数据
    to_encode = data.copy()
    # 设置token的过期时间
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    # 生成JWT Token
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    # 返回JWT Token
    return encoded_jwt
