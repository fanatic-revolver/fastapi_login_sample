from fastapi import FastAPI
from typing import Optional
from fastapi import Header


app = FastAPI()


@app.get("/")
async def index(user_agent: Optional[str] = Header(None)):
    return {"message": user_agent}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app")