import pymysql
from peewee import *
from playhouse.shortcuts import ReconnectMixin
from config.db import db_config

pymysql.install_as_MySQLdb()


# 同步数据库
# 同步数据库断线重连类
class ReconnectMySQLDatabase(ReconnectMixin, MySQLDatabase):
    pass


# 数据库实例
db = ReconnectMySQLDatabase(**db_config)


# 基础模型
class BaseModel(Model):
    class Meta:
        database = db


db.connect()
