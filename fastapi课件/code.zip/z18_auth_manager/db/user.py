from peewee import *
from db.base import BaseModel
from utils.password import get_password


# 创建用户表
class User(BaseModel):
    username = CharField()
    password = CharField()
    role_id = IntegerField()


def db_register(username, password, role_id=0):
    """用户注册"""
    hashed_password = get_password(password)
    user = User(username=username, password=hashed_password, role_id=role_id)
    user.save()


def db_get_user_by_username(username):
    """根据用户名获取用户信息"""
    users = list(User.select().filter(User.username == username))
    if len(users) > 0:
        return users[0]
    return None
