from fastapi import FastAPI, Depends
from config.server import API_PREFIX
from depends.user import get_json_login_user
from router.user import router as user_router
from router.goods import router as good_router

app = FastAPI()
app.include_router(user_router, prefix=API_PREFIX, tags=["用户管理"])
app.include_router(good_router, prefix=API_PREFIX, tags=["商品管理"],
                   dependencies=[Depends(get_json_login_user)])

if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app")
