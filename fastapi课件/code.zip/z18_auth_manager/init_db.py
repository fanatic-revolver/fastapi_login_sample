from db.user import User, db_register
from db.base import db


def init_user():
    """初始化用户"""
    db_register("zhangdapeng", "zhangdapeng")


def init_db():
    """初始化数据库"""
    tables = [User]
    db.drop_tables(tables)
    db.create_tables(tables)

    init_user()


if __name__ == '__main__':
    init_db()
