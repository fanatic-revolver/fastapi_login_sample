from fastapi import APIRouter, Depends
from fastapi.security import OAuth2PasswordRequestForm
from utils.response import *
from router.user import get_user_data

router = APIRouter()


@router.post("/token", summary="Form登录")
async def login_form(form_data: OAuth2PasswordRequestForm = Depends()):
    print("Doc文档登录", form_data.username, form_data.password)
    response = get_user_data(form_data.username, form_data.password)
    data = response.get("data")
    return {"access_token": data.get("token"), "token_type": "bearer"}
