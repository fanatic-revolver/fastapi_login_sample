from fastapi import APIRouter, Depends
from db.user import db_register, db_get_user_by_username
from utils.common import is_equal
from utils.password import check_password
from utils.response import *
from schemas.user import RegisterSchema, LoginSchema, UpdatePasswordSchema
from utils.jwt import get_token
from utils.password import get_password
from depends.user import get_json_login_user

router = APIRouter()


# 注册接口
@router.post("/register", summary="用户注册")
async def register(schema: RegisterSchema):
    """
    注册接口
    """
    # 校验两次密码是否一致
    if not is_equal(schema.password, schema.re_password):
        return get_param_error_response("两次密码不一致")

    # 校验用户名是否已存在
    try:
        user = db_get_user_by_username(schema.username)
        if user is not None:
            return get_exists_response("该用户已存在")
    except Exception as e:
        print(e)
        return get_error_response(msg="连接MySQL服务失败")

    # 新增用户
    try:
        db_register(schema.username, schema.password)
        return get_response()
    except Exception as e:
        print(e)

    return get_error_response()


def get_user_data(username, password):
    # 获取用户
    user = None
    try:
        user = db_get_user_by_username(username)
        if user is None:
            return get_not_found_response("该用户不存在")
    except Exception as e:
        print(e)
        return get_error_response(msg="连接MySQL服务失败")

    # 校验密码是否正确
    if not check_password(password, user.password):
        return get_param_error_response("用户名或密码错误")

    # 生成token
    data = {
        "id": user.id,
        "username": user.username,
        "role_id": user.role_id,
    }
    data["token"] = get_token(data=data)
    return get_response(data=data)


@router.post("/login", summary="JSON登录")
async def login_json(json_data: LoginSchema):
    return get_user_data(json_data.username, json_data.password)


@router.put("/password", summary="密码修改")
async def put_password(schema: UpdatePasswordSchema):
    # 获取用户get_login_user
    user = None
    try:
        user = db_get_user_by_username(schema.username)
        if user is None:
            return get_not_found_response("该用户不存在")
    except Exception as e:
        print(e)
        return get_error_response(msg="连接MySQL服务失败")

    # 校验旧密码
    if not check_password(schema.old_password, user.password):
        return get_param_error_response("用户名或密码错误")

    # 校验两次密码是否一致
    if not is_equal(schema.password, schema.re_password):
        return get_param_error_response("两次密码不一致")

    # 修改密码
    user.password = get_password(schema.password)
    try:
        user.save()
    except Exception as e:
        print(e)
        return get_error_response(msg="连接MySQL服务失败")

    return get_response()


@router.get("/userinfo", summary="获取用户信息")
async def get_userinfo(user=Depends(get_json_login_user)):
    """
    获取用户信息
    """
    data = {
        "id": user.id,
        "username": user.username,
        "role_id": user.role_id,
    }
    return get_response(data=data)
