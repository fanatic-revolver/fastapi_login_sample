from fastapi import APIRouter
from utils.response import *

router = APIRouter()


# 注册接口
@router.get("/goods", summary="获取商品列表")
async def get_goods(page: int = 1, size: int = 20):
    """获取商品信息"""
    return get_response()
