from pydantic import BaseModel


class LoginSchema(BaseModel):
    username: str
    password: str


class RegisterSchema(LoginSchema):
    re_password: str


class UpdatePasswordSchema(RegisterSchema):
    old_password: str
