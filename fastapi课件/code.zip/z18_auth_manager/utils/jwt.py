from datetime import datetime, timedelta
from jose import jwt
from config.jwt import SECRET_KEY, ALGORITHM, ACCESS_TOKEN_EXPIRE_MINUTES


def get_token(data: dict, expires_minute: int = ACCESS_TOKEN_EXPIRE_MINUTES):
    """
    生成token
    :param data: 要打包的数据
    :param expires_delta: 过期时间
    :return: JWT Token
    """
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=expires_minute)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt


def parse_token(token) -> dict:
    """
    解析Token
    """
    return jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
