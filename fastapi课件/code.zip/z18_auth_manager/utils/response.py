def get_response(msg="success", code=10000, status=True, data=None):
    """成功响应"""
    response = {"status": status, "code": code, "msg": msg}
    if data is not None:
        response["data"] = data
    return response


def get_error_response(msg="服务器内部错误", code=10003):
    """错误响应"""
    return get_response(code=code, status=False, msg=msg)


def get_param_error_response(msg):
    """参数错误响应"""
    return get_error_response(msg, code=10005)


def get_not_found_response(msg):
    """数据不存在错误响应"""
    return get_error_response(msg, code=10004)


def get_exists_response(msg):
    """数据已存在错误响应"""
    return get_error_response(msg, code=10006)
