from passlib.context import CryptContext

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def check_password(password_text, password_hash):
    """密码校验"""
    return pwd_context.verify(password_text, password_hash)


def get_password(password_text):
    """密码加密"""
    return pwd_context.hash(password_text)
