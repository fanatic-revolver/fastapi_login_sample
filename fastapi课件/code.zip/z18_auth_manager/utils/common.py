def is_equal(a, b):
    """判断是否相等"""
    return a == b
