from fastapi import Depends, HTTPException, status, Header
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError
from utils.jwt import parse_token
from db.user import db_get_user_by_username
from config.server import API_PREFIX

# OAuth2登录，文档登录
oauth2_scheme = OAuth2PasswordBearer(tokenUrl=f"{API_PREFIX}/token")


def get_user(token):
    """根据Token解析登录用户信息"""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="权限校验失败",
        headers={"WWW-Authenticate": "Bearer"},
    )

    if not token:
        raise credentials_exception

    try:
        # 解析token
        payload = parse_token(token)

        # 校验用户名
        username: str = payload.get("username")
        if username is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception

    # 获取用户
    user = None
    try:
        user = db_get_user_by_username(username)
        if user is None:
            raise credentials_exception
    except Exception as e:
        print(e)
        raise credentials_exception

    return user


def get_login_user(token: str = Depends(oauth2_scheme)):
    """获取登录用户"""
    return get_user(token)


def get_json_login_user(zdppy_jwt_token: str = Header()):
    """JSON接口获取登录用户"""
    return get_user(zdppy_jwt_token)

