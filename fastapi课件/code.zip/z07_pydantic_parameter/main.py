from fastapi import FastAPI, Body
from pydantic import BaseModel

class Student(BaseModel):
    name:str
    age:int=33

app = FastAPI()


@app.get("/")
async def index(student: Student):
    return student.dict()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app")